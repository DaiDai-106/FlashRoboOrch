from collections.abc import Sequence
import enum
from typing import Annotated, overload

import numpy
from numpy.typing import NDArray


def version() -> None:
    """Print version of ampl in terminal."""

class ArmType(enum.Enum):
    Humanoid7 = 3

    Industrial6 = 0

    CRX6 = 2

    UR6 = 1

Humanoid7: ArmType = ArmType.Humanoid7

Industrial6: ArmType = ArmType.Industrial6

CRX6: ArmType = ArmType.CRX6

UR6: ArmType = ArmType.UR6

def get_arm6_presets() -> list[str]:
    """Returns available presets of arm 6."""

def get_arm7_presets() -> list[str]:
    """Returns available presets of arm 7."""

class ArmBase:
    def __init__(self, arm_preset: str, arm_type: ArmType, dof: int) -> None:
        """create a preset arm solver"""

    def info(self) -> str: ...

    def joint_limits(self) -> tuple[list[float], list[float]]: ...

    def jacobian(self, arr_rwt: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')], J_global: NDArray[numpy.float64]) -> None: ...

    def fk_links(self, q: Annotated[NDArray[numpy.float64], dict(shape=(None,), device='cpu', writable=False)], arr_rwt: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')]) -> None:
        """len(q) >= dof, arr_rwt.shape = (dof+1,7), rwt=[rx,ry,rz,w,tx,ty,tz]"""

    def ik(self, m44_world_tool0: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')], arr_qik: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')]) -> int:
        """arr_qik.shape = (8,dof)"""

    def ik_iter(self, m44_world_tool0: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')], q_ref: NDArray[numpy.float64], q_ik: NDArray[numpy.float64], param_iter: NDArray[numpy.float64], nb_iter: int = 5) -> int:
        """param_iter needs at least 6 continous doubles"""

    def set_base(self, m44_world_base: Annotated[NDArray[numpy.float64], dict(shape=(None, None), device='cpu')]) -> None:
        """set pose of arm base in world"""

class Octreed:
    def __init__(self) -> None: ...

    def create(self, arg0: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], arg1: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')], arg2: Annotated[NDArray[numpy.uint32], dict(shape=(None, 2), device='cpu')], arg3: int, /) -> None: ...

    def nearest_neighbour(self, arg0: Annotated[NDArray[numpy.float64], dict(shape=(None, 3))], arg1: NDArray[numpy.float64], arg2: OcTreedEntityType, arg3: float, /) -> None: ...

class OcTreedEntityType(enum.Enum):
    Ver = 1

    Edg = 2

    Tri = 3

Ver: OcTreedEntityType = OcTreedEntityType.Ver

Edg: OcTreedEntityType = OcTreedEntityType.Edg

Tri: OcTreedEntityType = OcTreedEntityType.Tri

def warp_pixel_to_xyz(uv: Annotated[NDArray[numpy.float32], dict(shape=(None, 2), device='cpu')], plane: NDArray[numpy.float32], fx: float, fy: float, cx: float, cy: float, xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], rectify: bool = False) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]:
    """return a plane which best fits points"""

def ransac_plane3(pts: NDArray[numpy.float32], threshold: float, p_outlier: float) -> tuple[Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C')], float]:
    """return a plane which best fits points"""

def estimate_plane(pts: NDArray[numpy.float32]) -> tuple[Annotated[NDArray[numpy.float32], dict(shape=(None,), order='C')], float]:
    """return a plane which best fits points"""

def SO3_align(a: NDArray[numpy.float32], b: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(3, 3), order='C')]:
    """return R such that R a = b"""

def transform_so3_upexp(r3: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(3, 3), order='C')]:
    """return up exp."""

def transform_so3_downlog(R33: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(3), order='C')]:
    """return down log."""

def transform_se3_downlog(R33: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(6), order='C')]:
    """return down log."""

def transform_se3_upexp(r3: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]:
    """return up exp."""

def bounding_obb_point2(xy: Annotated[NDArray[numpy.float32], dict(shape=(None, 2), device='cpu')]) -> list[float]:
    """return obb2 [center_x, center_y, angle, extent]"""

def bounding_obb_point3(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')]) -> tuple[list[float], list[float], Annotated[NDArray[numpy.float32], dict(shape=(3, 3), order='C')]]:
    """return obb3 [center_x, center_y, angle, extent]"""

def bounding_sphere_point3(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], method: str = 'fast') -> list[float]:
    """
    return sphere [center_x, center_y, center_z, radius]. method = fast or minball
    """

def transform_xyz(xyz_src: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], xyz_dst: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], rwt: Annotated[NDArray[numpy.float32], dict(device='cpu')]) -> None: ...

def sample_polyline_uniform(waypoints: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], nb_interpolate: int) -> NDArray[numpy.float32]:
    """uniform interplate n-dimensional poly along arclength."""

def so3_upexp(r: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float64], dict(shape=(3, 3), order='F')]:
    """return exp of r"""

@overload
def rwtmul(rwtA: NDArray[numpy.float32], rwtB: NDArray[numpy.float32]) -> Annotated[NDArray[numpy.float32], dict(shape=(7), order='C')]:
    """return rwtAB"""

@overload
def rwtmul(rwtA: NDArray[numpy.float64], rwtB: NDArray[numpy.float64]) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

@overload
def tf44_to_qt7(tf44: Annotated[NDArray[numpy.float32], dict(shape=(4, 4))]) -> Annotated[NDArray[numpy.float32], dict(shape=(7), order='C')]:
    """return qt7"""

@overload
def tf44_to_qt7(tf44: Annotated[NDArray[numpy.float64], dict(shape=(4, 4))]) -> Annotated[NDArray[numpy.float64], dict(shape=(7), order='C')]: ...

@overload
def qt7_to_tf44(qt7: Annotated[NDArray[numpy.float64], dict(shape=(None,))]) -> Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='C')]:
    """return tf44"""

@overload
def qt7_to_tf44(qt7: Annotated[NDArray[numpy.float32], dict(shape=(None,))]) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]: ...

@overload
def wxyz_t_to_tf44(wxyz: Annotated[NDArray[numpy.float64], dict(shape=(None,))], t: Annotated[NDArray[numpy.float64], dict(shape=(None,))]) -> Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='C')]:
    """return tf44"""

@overload
def wxyz_t_to_tf44(wxyz: Annotated[NDArray[numpy.float32], dict(shape=(None,))], t: Annotated[NDArray[numpy.float32], dict(shape=(None,))]) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]: ...

def distancefield_xyz2occ(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), order='C', device='cpu')], occ: NDArray[numpy.uint8], shape: NDArray[numpy.uint32], origin: NDArray[numpy.float32], dx: float) -> None:
    """This function computes an occupation grid from a point cloud"""

def distancefield_occ2edf(occ: Annotated[NDArray[numpy.uint8], dict(shape=(None, 3), order='C', device='cpu')], edf: NDArray[numpy.float32], shape: NDArray[numpy.uint32], origin: NDArray[numpy.float32], dx: float, nb_worker: int = 4) -> None:
    """
    This function computes an euclidean distance field from a occupation grid
    """

def distancefield_xyz2edf(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), order='C', device='cpu')], occ: NDArray[numpy.uint8], edf: NDArray[numpy.float32], shape: NDArray[numpy.uint32], origin: NDArray[numpy.float32], dx: float, nb_worker: int = 4) -> None:
    """This function computes an euclidean distance field from a point cloud"""

def distancefield_df2trimesh(df: NDArray[numpy.float32], mc_level: float, shape: NDArray[numpy.uint32], origin: NDArray[numpy.float32], dx: float) -> tuple[NDArray[numpy.float32], NDArray[numpy.uint32]]:
    """
    This function performs marching cube on a distance field under a given level.
    """

@overload
def frame3_contact(frame_position_in_world: NDArray[numpy.float32], frame_tangent_in_world: NDArray[numpy.float32], frame_normal_in_world: NDArray[numpy.float32], contact_position_in_frame: NDArray[numpy.float32], contact_direction_in_frame: NDArray[numpy.float32], contact_position_in_tool: NDArray[numpy.float32], contact_direction_in_tool: NDArray[numpy.float32], align_direction_in_target: NDArray[numpy.float32], align_direction_in_tool: NDArray[numpy.float32], is_target_frame_or_world: int = 1) -> Annotated[NDArray[numpy.float32], dict(shape=(4, 4), order='C')]:
    """This function computes contact."""

@overload
def frame3_contact(frame_position_in_world: NDArray[numpy.float64], frame_tangent_in_world: NDArray[numpy.float64], frame_normal_in_world: NDArray[numpy.float64], contact_position_in_frame: NDArray[numpy.float64], contact_direction_in_frame: NDArray[numpy.float64], contact_position_in_tool: NDArray[numpy.float64], contact_direction_in_tool: NDArray[numpy.float64], align_direction_in_target: NDArray[numpy.float64], align_direction_in_tool: NDArray[numpy.float64], is_target_frame_or_world: int = 1) -> Annotated[NDArray[numpy.float64], dict(shape=(4, 4), order='C')]: ...

def get_stl_data(arg: str, /) -> tuple: ...

def trimesh_vhacd(vertices: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], indices: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')], maxConvexHulls: int = 64, resolution: int = 400000, minimumVolumePercentErrorAllowed: float = 1.0, maxRecursionDepth: int = 10, shrinkWrap: bool = True, fillMode: str = 'flood', maxNumVerticesPerCH: int = 64, asyncACD: bool = True, minEdgeLength: int = 2, findBestPlane: bool = False) -> object:
    """This function wraps around vhacd."""

def trimesh_sampler_barycentricysplit(vertices: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], indices: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')], nb_samples_expect: int, sample_distance_expect: float) -> Annotated[NDArray[numpy.float32], dict(shape=(None, None))]:
    """
    This function samples pointcloud from a mesh by barycentric face-splitting.
    """

def trimesh_raycast(vertices: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], indices: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')], origins_ray: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], directions_ray: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], ret_hit_indice: bool = False, nb_worker: int = 1) -> tuple[NDArray[numpy.float64], NDArray[numpy.uint32]]:
    """
    This function performs distance queries of a point cloud against a distance field
    """

def trimesh_connected_components(indices: Annotated[NDArray[numpy.uint32], dict(shape=(None, 3), device='cpu')]) -> list[list[int]]:
    """Return connected components according to face connectivity."""

def trimesh_convexhull(vertices: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], epsilon: float = 1e-05) -> tuple[NDArray[numpy.float32], NDArray[numpy.uint32]]:
    """Return vertices and faces of a convex hull."""

class VSphG8f:
    def __init__(self) -> None: ...

    @property
    def nb_sph(self) -> int: ...

    @nb_sph.setter
    def nb_sph(self, arg: int, /) -> None: ...

    @property
    def nb_offset(self) -> int: ...

    @nb_offset.setter
    def nb_offset(self, arg: int, /) -> None: ...

class VCvhf:
    @overload
    def __init__(self) -> None: ...

    @overload
    def __init__(self, arg: VCvhf) -> None: ...

    def size(self) -> int: ...

    def sizes(self) -> list[int]: ...

class DistanceField:
    def __init__(self) -> None: ...

    @property
    def shape(self) -> list[int]: ...

    @shape.setter
    def shape(self, arg: Sequence[int], /) -> None: ...

    @property
    def origin(self) -> list[float]: ...

    @origin.setter
    def origin(self, arg: Sequence[float], /) -> None: ...

    @property
    def side(self) -> float: ...

    @side.setter
    def side(self, arg: float, /) -> None: ...

    def allocate_buffer(self) -> None: ...

    def clear(self) -> None: ...

class OBB3:
    def __init__(self) -> None: ...

    @property
    def center(self) -> list[float]: ...

    @center.setter
    def center(self, arg: Sequence[float], /) -> None: ...

    @property
    def u(self) -> list[float]: ...

    @u.setter
    def u(self, arg: Sequence[float], /) -> None: ...

    @property
    def v(self) -> list[float]: ...

    @v.setter
    def v(self, arg: Sequence[float], /) -> None: ...

    @property
    def w(self) -> list[float]: ...

    @w.setter
    def w(self, arg: Sequence[float], /) -> None: ...

    @property
    def half_extents(self) -> list[float]: ...

    @half_extents.setter
    def half_extents(self, arg: Sequence[float], /) -> None: ...

@overload
def collision_initialize_object(xyzr: Annotated[NDArray[numpy.float32], dict(shape=(None, 4), device='cpu')], offset: Annotated[NDArray[numpy.uint32], dict(shape=(None,), device='cpu')], VSphG8f: VSphG8f) -> None:
    """Initialize spheres into vectorized data buffer."""

@overload
def collision_initialize_object(xyz: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], df: DistanceField, nb_worker: int = 4) -> None:
    """Initialize df from xyz."""

@overload
def collision_initialize_object(xyz: Sequence[Annotated[NDArray[numpy.float32], dict(shape=(None, 3))]], cvx_obj: VCvhf) -> None:
    """Initialize cvx_obj from xyz."""

@overload
def collision_visualize_object(df: DistanceField, field_level: float) -> tuple[NDArray[numpy.float32], NDArray[numpy.uint32]]:
    """
    This function performs marching cube on a distance field object for a given field level.
    """

@overload
def collision_visualize_object(spheres: VSphG8f, nb_v_per_sphere: int = 32) -> tuple[NDArray[numpy.float32], NDArray[numpy.uint32]]:
    """This function create a mesh version of packed spheres."""

def collision_transform_object_inplace(spheres: VSphG8f, i_sph: int, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms packed spheres in place."""

@overload
def collision_transform_object(spheres_src: VSphG8f, spheres_dst: VSphG8f, i_sph: int, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms packed spheres in place."""

@overload
def collision_transform_object(spheres_src: VSphG8f, spheres_dst: VSphG8f, i_sph: int, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms packed spheres in place."""

@overload
def collision_transform_object(cvhs_src: VCvhf, cvhs_dst: VCvhf, rwt: NDArray[numpy.float32]) -> None:
    """This function transforms packed convex hulls."""

@overload
def collision_check_df_vsph(df: DistanceField, spheres: VSphG8f, i_sph: int, d_safe: float) -> bool:
    """
    This function computes intersection between distance field and packed spheres.
    """

@overload
def collision_check_df_vsph(df: DistanceField, spheres: VSphG8f, i_sph: int, d_safe: float, wall: Annotated[NDArray[numpy.float32], dict(shape=(None,), device='cpu')]) -> bool: ...

def collision_check_vcvh_vcvh(vcvhA: VCvhf, vcvhB: VCvhf, d_safe: float = 9.999999747378752e-05) -> float:
    """
    This function computes intersection between distance field and packed spheres.
    """

@overload
def collision_check_obb_vsph(obb: OBB3, spheres: VSphG8f, i_sph: int) -> bool:
    """
    This function computes intersection between oriented bounding box (3d) and packed spheres.
    """

@overload
def collision_check_obb_vsph(obb: OBB3, spheres: VSphG8f, i_sph: int, wall: Annotated[NDArray[numpy.float32], dict(shape=(None,), device='cpu')]) -> bool:
    """
    This function computes intersection between oriented bounding box (3d) and packed spheres subject to wall.
    """

def collision_check_xyzwall_vsph(wall: Annotated[NDArray[numpy.float32], dict(shape=(None,), device='cpu')], spheres: VSphG8f, i_sph: int) -> bool:
    """
    This function computes intersection between axis-aligned infinite walls and packed spheres.
    """

@overload
def collision_check_cvx_cvx(cxvA: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')], cvxB: Annotated[NDArray[numpy.float64], dict(shape=(None, 3), device='cpu')]) -> float:
    """This function computes intersection between two convex hull."""

@overload
def collision_check_cvx_cvx(cxvA: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')], cvxB: Annotated[NDArray[numpy.float32], dict(shape=(None, 3), device='cpu')]) -> float: ...

class RNG3:
    def __init__(self) -> None: ...

    def set_range(self, arg0: NDArray[numpy.float64], arg1: NDArray[numpy.float64], /) -> None: ...

    def reset(self) -> None: ...

    def seed(self, arg: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float32], arg1: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float64], arg1: int, /) -> None: ...

class RNG6:
    def __init__(self) -> None: ...

    def set_range(self, arg0: NDArray[numpy.float64], arg1: NDArray[numpy.float64], /) -> None: ...

    def reset(self) -> None: ...

    def seed(self, arg: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float32], arg1: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float64], arg1: int, /) -> None: ...

class RNG7:
    def __init__(self) -> None: ...

    def set_range(self, arg0: NDArray[numpy.float64], arg1: NDArray[numpy.float64], /) -> None: ...

    def reset(self) -> None: ...

    def seed(self, arg: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float32], arg1: int, /) -> None: ...

    @overload
    def next(self, arg0: NDArray[numpy.float64], arg1: int, /) -> None: ...

def graph_from_polyline(waypoints: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], nb_internal: int = 1) -> tuple[dict[int, list[tuple[int, float]]], NDArray[numpy.float32]]:
    """densify and create graph"""

def graph_dijkstra_single(adj: dict, nb_vertex: int, src: int, dst: int) -> tuple[float, list[int]]:
    """dijkstra"""

def graph_distance_matrix_l2(xa: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], xb: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], mab: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')]) -> None:
    """
    dense distance matrix. mab is row major. mab.shape = (xb.shape[1], xa.shape[1])
    """

def algo_debug() -> None: ...

def image_apriltags_create_grid(xyz_nx4x3: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 3), device='cpu')], family: int = 6, tag_size: float = 88.0, tag_spacing: float = 0.3) -> None:
    """This function extracts apriltags for 36h11"""

def image_apriltags(gray: Annotated[NDArray[numpy.float32], dict(shape=(None, None), device='cpu')], corners_nx4x2: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 2), device='cpu')], family: int = 6, nb_black_border: int = 2) -> list[int]:
    """This function extracts apriltags for 36h11"""

def image_roi(mask: Annotated[NDArray[numpy.uint8], dict(shape=(None, None), device='cpu')], ids: Sequence[int] = []) -> dict[int, list[int]]:
    """This function extracts rois from a multi-labelled mask"""

def image_depth_to_xyz(dI: Annotated[NDArray[numpy.uint16], dict(shape=(None, None), device='cpu')], fx: float, fy: float, cx: float, cy: float, xyzI: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 3), device='cpu')], scale: float = -1.0, z_min_after_scale: float = 0.0, z_max_after_scale: float = 65535.0) -> None:
    """depth image to xyz image"""

def image_xyz_to_normal(arg0: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 3), device='cpu')], arg1: float, arg2: float, arg3: Annotated[NDArray[numpy.float32], dict(shape=(None, None, 3), device='cpu')], /) -> None:
    """xyz image to nx ny nz image"""
