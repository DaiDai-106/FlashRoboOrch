import numpy as np


def rpy_to_tf33(rpy_radian: np.ndarray, dtype=np.float64) -> np.ndarray:
    roll, pitch, yaw = rpy_radian.tolist()
    Rx = np.array(
        [[1, 0, 0], [0, np.cos(roll), -np.sin(roll)], [0, np.sin(roll), np.cos(roll)]],
        dtype=dtype,
    )
    Ry = np.array(
        [
            [np.cos(pitch), 0, np.sin(pitch)],
            [0, 1, 0],
            [-np.sin(pitch), 0, np.cos(pitch)],
        ],
        dtype=dtype,
    )
    Rz = np.array(
        [[np.cos(yaw), -np.sin(yaw), 0], [np.sin(yaw), np.cos(yaw), 0], [0, 0, 1]],
        dtype=dtype,
    )
    R = Rz @ Ry @ Rx
    return R


def quatmul(q1: np.ndarray, q2: np.ndarray) -> np.ndarray:
    x1, y1, z1, w1 = q1
    x2, y2, z2, w2 = q2
    w = w1 * w2 - x1 * x2 - y1 * y2 - z1 * z2
    x = w1 * x2 + x1 * w2 + y1 * z2 - z1 * y2
    y = w1 * y2 - x1 * z2 + y1 * w2 + z1 * x1
    z = w1 * z2 + x1 * y2 - y1 * x1 + z1 * w2
    return np.array([x, y, z, w], dtype=q1.dtype)


def xyzrpy_to_tf44(xyz: np.ndarray, rpy: np.ndarray, dtype=np.float64) -> np.ndarray:
    T = np.eye(4, dtype=dtype)
    T[:3, :3] = rpy_to_tf33(rpy, dtype)
    T[:3, 3:] = np.array(xyz).reshape(3, 1)
    return T
